import{c as b}from"./index-DEk862HE.js";import k from"./purify.es-CYR4BTuT.js";/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=[["path",{d:"m21 16-4 4-4-4",key:"f6ql7i"}],["path",{d:"M17 20V4",key:"1ejh1v"}],["path",{d:"m3 8 4-4 4 4",key:"11wl7u"}],["path",{d:"M7 4v16",key:"1glfcx"}]],H=b("arrow-up-down",v);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=[["path",{d:"M20 10a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2.5a1 1 0 0 1-.8-.4l-.9-1.2A1 1 0 0 0 15 3h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",key:"hod4my"}],["path",{d:"M20 21a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-2.9a1 1 0 0 1-.88-.55l-.42-.85a1 1 0 0 0-.92-.6H13a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",key:"w4yl2u"}],["path",{d:"M3 5a2 2 0 0 0 2 2h3",key:"f2jnh7"}],["path",{d:"M3 3v13a2 2 0 0 0 2 2h3",key:"k8epm1"}]],j=b("folder-tree",W);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=[["path",{d:"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",key:"sc7q7i"}]],z=b("funnel",A);/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */function L(c,s){if(!c)return"";let r=c.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi," ").replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi," ").replace(/<[^>]+>/g," ").replace(/<[a-z0-9_\-\s"=':;\.\/]+>?/gi," ").replace(/<[^>]*$/g," ").replace(/\*\*([^*]+)\*\*/g,"$1").replace(/\*([^*]+)\*/g,"$1").replace(/~~([^~]+)~~/g,"$1").replace(/^(\*|\-|•|\d+\.)\s+/gm,"").replace(/\[([^\]]+)\]\([^)]+\)/g,"$1").replace(/#+\s+/g,"").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&quot;/gi,'"').replace(/&#39;/gi,"'").replace(/&lt;/gi,"<").replace(/&gt;/gi,">").replace(/\s+/g," ").trim();return s&&r.length>s?r.slice(0,s).trim()+"...":r}function _(c){if(!c||!c.includes("|"))return c;const r=c.replace(/\|\s*\|\s*/g,`|
|`).split(/\r?\n/),n=[];let l=0;const g=o=>{const t=o.trim();return t.includes("|")&&!t.startsWith("```")&&!t.startsWith("<div")&&!t.startsWith("</div")&&!t.startsWith("<table")&&!t.startsWith("</table")},x=o=>{const t=o.trim();return/^\|?[\s:\-\|]+\|?$/.test(t)&&t.includes("-")};for(;l<r.length;){const o=r[l].trim();if(g(o)&&l+1<r.length&&x(r[l+1])){let t=o;t.startsWith("|")&&(t=t.slice(1)),t.endsWith("|")&&(t=t.slice(0,-1));const m=t.split("|").map(a=>a.trim());let d=r[l+1].trim();d.startsWith("|")&&(d=d.slice(1)),d.endsWith("|")&&(d=d.slice(0,-1));const f=d.split("|").map(a=>{const p=a.trim();return p.startsWith(":")&&p.endsWith(":")?"center":p.endsWith(":")?"right":"left"}),i=[];for(l+=2;l<r.length&&g(r[l])&&!x(r[l]);){let a=r[l].trim();if(!a)break;a.startsWith("|")&&(a=a.slice(1)),a.endsWith("|")&&(a=a.slice(0,-1));const p=a.split("|").map(u=>u.trim());i.push(p),l++}let e=`
<div class="my-6 overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-2xs">
`;e+=`  <table class="w-full text-left text-xs sm:text-sm border-collapse min-w-[500px]">
`,e+=`    <thead class="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700">
`,e+=`      <tr>
`,m.forEach((a,p)=>{const u=f[p]||"left",h=a.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\*(.*?)\*/g,"<em>$1</em>");e+=`        <th class="py-3 px-4 font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider text-[11px] text-${u}">${h}</th>
`}),e+=`      </tr>
`,e+=`    </thead>
`,e+=`    <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
`,i.forEach((a,p)=>{const u=p%2===1?"bg-slate-50/40 dark:bg-slate-800/30":"bg-white dark:bg-slate-900";e+=`      <tr class="${u} hover:bg-indigo-50/30 dark:hover:bg-slate-800/60 transition-colors">
`;for(let h=0;h<m.length;h++){const $=a[h]||"",w=f[h]||"left",y=$.replace(/\*\*(.*?)\*\*/g,'<strong class="font-bold text-slate-900 dark:text-white">$1</strong>').replace(/\*(.*?)\*/g,'<em class="italic">$1</em>').replace(/~~(.*?)~~/g,'<del class="line-through text-slate-400">$1</del>');e+=`        <td class="py-3 px-4 text-${w}">${y}</td>
`}e+=`      </tr>
`}),e+=`    </tbody>
`,e+=`  </table>
`,e+=`</div>
`,n.push(e);continue}n.push(r[l]),l++}return n.join(`
`)}function R(c){if(!c||!c.trim())return"";let s=c.trim();if(s=_(s),/<(div|table|section|article|figure|ul|ol|header|footer|video|iframe)\b/i.test(s)||/<p\b/i.test(s)&&/<\/[a-z]+>/i.test(s))return k.sanitize(s,{ADD_TAGS:["iframe","video","source","table","thead","tbody","tr","th","td","caption"],ADD_ATTR:["allow","allowfullscreen","frameborder","scrolling","target","class","style","colspan","rowspan","scope"]});s=s.replace(/([^\n])\s*(\*|\-)\s+\*\*/g,`$1
* **`),s=s.replace(/([^\n])\s*(\*|\-)\s+([A-Z])/g,`$1
* $3`),s=s.replace(/([.!?])\s*\*\*([^*]{3,40})\*\*/g,`$1

**$2**
`),s=s.replace(/([.!?])\s*\*\*([^*]{15,})\*\*/g,`$1

**$2**`);const r=s.split(/\r?\n/),n=[];let l=[];const g=()=>{l.length>0&&(n.push('<ul class="my-3.5 space-y-2 text-slate-700 dark:text-slate-300">'+l.map(o=>`<li class="flex items-start gap-2.5 text-xs sm:text-sm leading-relaxed"><span class="inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-indigo-100/70 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-bold text-[10px] mt-0.5 shadow-5xs">•</span><span>${o}</span></li>`).join("")+"</ul>"),l=[])};for(let o=0;o<r.length;o++){const t=r[o].trim();if(!t){g();continue}const m=t.match(/^(\*|\-|•|\d+\.)\s+(.+)$/);if(m){let e=m[2];e=e.replace(/\*\*(.*?)\*\*/g,'<strong class="font-bold text-slate-900 dark:text-white">$1</strong>'),e=e.replace(/\*(.*?)\*/g,'<em class="italic">$1</em>'),l.push(e);continue}g();const d=t.match(/^(#{1,4})\s+(.+)$/);if(d){const e=d[1].length,a=d[2].replace(/\*\*(.*?)\*\*/g,"$1");e===1?n.push(`<h3 class="text-base font-bold text-slate-900 dark:text-white mt-4 mb-2 font-display tracking-tight">${a}</h3>`):e===2?n.push(`<h4 class="text-sm font-bold text-slate-900 dark:text-white mt-3.5 mb-1.5 flex items-center gap-1.5 font-display tracking-tight"><span class="h-2 w-2 rounded-full bg-indigo-500 inline-block"></span>${a}</h4>`):n.push(`<h5 class="text-xs font-bold text-slate-800 dark:text-slate-200 mt-3 mb-1 uppercase tracking-wider font-mono">${a}</h5>`);continue}const f=t.match(/^\*\*([^*]+)\*\*$/);if(f){n.push(`<h4 class="text-xs sm:text-sm font-bold text-indigo-950 dark:text-indigo-200 mt-4 mb-2 flex items-center gap-1.5 font-display tracking-tight"><span class="h-1.5 w-1.5 rounded-full bg-indigo-600 inline-block"></span>${f[1]}</h4>`);continue}let i=t;i=i.replace(/\*\*(.*?)\*\*/g,'<strong class="font-bold text-slate-900 dark:text-white">$1</strong>'),i=i.replace(/\*(.*?)\*/g,'<em class="italic">$1</em>'),i=i.replace(/~~(.*?)~~/g,'<del class="line-through text-slate-400">$1</del>'),i=i.replace(/\[(.*?)\]\((.*?)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer" class="text-indigo-600 dark:text-indigo-400 font-semibold underline hover:opacity-80">$1</a>'),t.startsWith("**")&&t.endsWith("**")?n.push(`<div class="my-3.5 p-4 rounded-xl border border-indigo-100 dark:border-indigo-900/60 bg-gradient-to-r from-indigo-50/50 via-white to-indigo-50/30 dark:from-indigo-950/40 dark:via-gray-900 dark:to-indigo-950/30 text-indigo-950 dark:text-indigo-200 text-xs sm:text-sm font-medium leading-relaxed shadow-3xs">${i}</div>`):n.push(`<p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-normal leading-relaxed my-2">${i}</p>`)}g();const x=n.join(`
`);return k.sanitize(x,{ADD_TAGS:["iframe","video","source","table","thead","tbody","tr","th","td","caption"],ADD_ATTR:["allow","allowfullscreen","frameborder","scrolling","target","class","style","colspan","rowspan","scope"]})}export{H as A,z as F,j as a,L as c,R as f};
