import{c as g}from"./index-D7DgnmAo.js";import m from"./purify.es-CYR4BTuT.js";/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=[["path",{d:"m21 16-4 4-4-4",key:"f6ql7i"}],["path",{d:"M17 20V4",key:"1ejh1v"}],["path",{d:"m3 8 4-4 4 4",key:"11wl7u"}],["path",{d:"M7 4v16",key:"1glfcx"}]],w=g("arrow-up-down",x);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=[["path",{d:"M20 10a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2.5a1 1 0 0 1-.8-.4l-.9-1.2A1 1 0 0 0 15 3h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",key:"hod4my"}],["path",{d:"M20 21a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-2.9a1 1 0 0 1-.88-.55l-.42-.85a1 1 0 0 0-.92-.6H13a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",key:"w4yl2u"}],["path",{d:"M3 5a2 2 0 0 0 2 2h3",key:"f2jnh7"}],["path",{d:"M3 3v13a2 2 0 0 0 2 2h3",key:"k8epm1"}]],v=g("folder-tree",k);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=[["path",{d:"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",key:"sc7q7i"}]],A=g("funnel",b);/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */function M(l,e){if(!l)return"";let n=l.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi," ").replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi," ").replace(/<[^>]+>/g," ").replace(/<[a-z0-9_\-\s"=':;\.\/]+>?/gi," ").replace(/<[^>]*$/g," ").replace(/\*\*([^*]+)\*\*/g,"$1").replace(/\*([^*]+)\*/g,"$1").replace(/~~([^~]+)~~/g,"$1").replace(/^(\*|\-|•|\d+\.)\s+/gm,"").replace(/\[([^\]]+)\]\([^)]+\)/g,"$1").replace(/#+\s+/g,"").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&quot;/gi,'"').replace(/&#39;/gi,"'").replace(/&lt;/gi,"<").replace(/&gt;/gi,">").replace(/\s+/g," ").trim();return e&&n.length>e?n.slice(0,e).trim()+"...":n}function _(l){if(!l||!l.trim())return"";let e=l.trim();if(/<(div|table|section|article|figure|ul|ol|header|footer|video|iframe)\b/i.test(e)||/<p\b/i.test(e)&&/<\/[a-z]+>/i.test(e))return m.sanitize(e,{ADD_TAGS:["iframe","video","source"],ADD_ATTR:["allow","allowfullscreen","frameborder","scrolling","target"]});e=e.replace(/([^\n])\s*(\*|\-)\s+\*\*/g,`$1
* **`),e=e.replace(/([^\n])\s*(\*|\-)\s+([A-Z])/g,`$1
* $3`),e=e.replace(/([.!?])\s*\*\*([^*]{3,40})\*\*/g,`$1

**$2**
`),e=e.replace(/([.!?])\s*\*\*([^*]{15,})\*\*/g,`$1

**$2**`);const n=e.split(/\r?\n/),a=[];let o=[];const c=()=>{o.length>0&&(a.push('<ul class="my-3.5 space-y-2 text-slate-700 dark:text-slate-300">'+o.map(r=>`<li class="flex items-start gap-2.5 text-xs sm:text-sm leading-relaxed"><span class="inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-indigo-100/70 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-bold text-[10px] mt-0.5 shadow-5xs">•</span><span>${r}</span></li>`).join("")+"</ul>"),o=[])};for(let r=0;r<n.length;r++){const i=n[r].trim();if(!i){c();continue}const h=i.match(/^(\*|\-|•|\d+\.)\s+(.+)$/);if(h){let s=h[2];s=s.replace(/\*\*(.*?)\*\*/g,'<strong class="font-bold text-slate-900 dark:text-white">$1</strong>'),s=s.replace(/\*(.*?)\*/g,'<em class="italic">$1</em>'),o.push(s);continue}c();const d=i.match(/^(#{1,4})\s+(.+)$/);if(d){const s=d[1].length,p=d[2].replace(/\*\*(.*?)\*\*/g,"$1");s===1?a.push(`<h3 class="text-base font-bold text-slate-900 dark:text-white mt-4 mb-2 font-display tracking-tight">${p}</h3>`):s===2?a.push(`<h4 class="text-sm font-bold text-slate-900 dark:text-white mt-3.5 mb-1.5 flex items-center gap-1.5 font-display tracking-tight"><span class="h-2 w-2 rounded-full bg-indigo-500 inline-block"></span>${p}</h4>`):a.push(`<h5 class="text-xs font-bold text-slate-800 dark:text-slate-200 mt-3 mb-1 uppercase tracking-wider font-mono">${p}</h5>`);continue}const f=i.match(/^\*\*([^*]+)\*\*$/);if(f){a.push(`<h4 class="text-xs sm:text-sm font-bold text-indigo-950 dark:text-indigo-200 mt-4 mb-2 flex items-center gap-1.5 font-display tracking-tight"><span class="h-1.5 w-1.5 rounded-full bg-indigo-600 inline-block"></span>${f[1]}</h4>`);continue}let t=i;t=t.replace(/\*\*(.*?)\*\*/g,'<strong class="font-bold text-slate-900 dark:text-white">$1</strong>'),t=t.replace(/\*(.*?)\*/g,'<em class="italic">$1</em>'),t=t.replace(/~~(.*?)~~/g,'<del class="line-through text-slate-400">$1</del>'),t=t.replace(/\[(.*?)\]\((.*?)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer" class="text-indigo-600 dark:text-indigo-400 font-semibold underline hover:opacity-80">$1</a>'),i.startsWith("**")&&i.endsWith("**")?a.push(`<div class="my-3.5 p-4 rounded-xl border border-indigo-100 dark:border-indigo-900/60 bg-gradient-to-r from-indigo-50/50 via-white to-indigo-50/30 dark:from-indigo-950/40 dark:via-gray-900 dark:to-indigo-950/30 text-indigo-950 dark:text-indigo-200 text-xs sm:text-sm font-medium leading-relaxed shadow-3xs">${t}</div>`):a.push(`<p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-normal leading-relaxed my-2">${t}</p>`)}c();const u=a.join(`
`);return m.sanitize(u)}export{w as A,A as F,v as a,M as c,_ as f};
