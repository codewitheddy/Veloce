import{c as m}from"./index-Cl3DlJsp.js";/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["path",{d:"M11 14h10",key:"1w8e9d"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v1.344",key:"1e62lh"}],["path",{d:"m17 18 4-4-4-4",key:"z2g111"}],["path",{d:"M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 1.793-1.113",key:"bjbb7m"}],["rect",{x:"8",y:"2",width:"8",height:"4",rx:"1",key:"ublpy"}]],l=m("clipboard-paste",u);/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * M-Pesa parsing and Kenyan phone validation utilities.
 */function f(s){if(!s||typeof s!="string")return!1;const t=s.replace(/[\s\-\(\)\.]/g,"");return/^(?:(?:\+?254)|0)?([17]\d{8})$/.test(t)}function M(s){const t={code:null,amount:null,phoneNumber:null,recipient:null,dateTime:null,isExtractedFromSMS:!1,rawText:s};if(!s||typeof s!="string")return t;const e=s.trim();if(!e)return t;const h=e.match(/^[A-Z0-9]{8,12}$/i);if(h&&!e.includes(" ")&&!e.includes(`
`))return t.code=h[0].toUpperCase(),t;const n=e.match(/\b([A-Z0-9]{8,12})\s+Confirmed/i);if(n&&n[1])t.code=n[1].toUpperCase(),t.isExtractedFromSMS=!0;else{const d=e.match(/\b([A-Z0-9]{8,12})\b/gi)||[];for(const a of d){const o=a.toUpperCase();if(!["CONFIRMED","PAYBILL","BALANCE","ACCOUNT","ROPENIX","INVESTMENTS","TRANSACTION","SAFARICOM"].includes(o)&&/[A-Z]/.test(o)&&/[0-9]/.test(o)){t.code=o,t.isExtractedFromSMS=!0;break}}}const r=e.match(/(?:Ksh|Kshs|KES|\$)\s*([\d,]+(?:\.\d{2})?)/i)||e.match(/amount\s+(?:of\s+)?(?:Ksh|KES)?\s*([\d,]+(?:\.\d{2})?)/i);if(r&&r[1]){const d=r[1].replace(/,/g,""),a=parseFloat(d);!isNaN(a)&&a>0&&(t.amount=a)}const c=e.match(/(?:from|to|number|phone)\s*(?:\+?254|0)?([17]\d{8})\b/i);c&&c[1]&&(t.phoneNumber="0"+c[1]);const i=e.match(/on\s+(\d{1,2}\/\d{1,2}\/\d{2,4})\s+at\s+(\d{1,2}:\d{2}\s*(?:AM|PM)?)/i);return i&&(t.dateTime=`${i[1]} ${i[2]}`),t}export{l as C,f as i,M as p};
