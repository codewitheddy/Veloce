from django.apps import AppConfig

class SuppliersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.suppliers'
    label = 'suppliers'
    verbose_name = 'Supplier Management & Consignment'
